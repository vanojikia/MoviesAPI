﻿using Microsoft.AspNetCore.Mvc;
using MoviesAPI.Models;
using MoviesAPI.Services;

namespace MoviesAPI.Controllers
{
    [ApiController]
    [Route("movie")]
    public class MoviesController : ControllerBase
    {
        private readonly IMoviesService _moviesService;

        public MoviesController(IMoviesService moviesService)
        {
            _moviesService = moviesService;
        }

        [HttpPost("add")]
        public ActionResult<Movie> AddMovie([FromBody] Movie movie)
        {
            return Ok(_moviesService.AddMovie(movie));
        }

        [HttpGet("get")]
        public ActionResult<Movie> GetMovie([FromQuery] int id)
        {
            return Ok(_moviesService.GetMovie(id));
        }

        [HttpGet("search")]
        public ActionResult SearchMovies([FromQuery] string query)
        {
            return Ok(_moviesService.SearchMovies(query));
        }

        [HttpPut("update")]
        public ActionResult UpdateMovie([FromBody] Movie movie)
        {
            if (_moviesService.UpdateMovie(movie))
                return Ok();
            return NotFound();
        }

        [HttpDelete("delete")]
        public ActionResult DeleteMovie([FromQuery] int id)
        {
            if (_moviesService.DeleteMovie(id))
                return Ok();
            return NotFound();
        }
    }
}
