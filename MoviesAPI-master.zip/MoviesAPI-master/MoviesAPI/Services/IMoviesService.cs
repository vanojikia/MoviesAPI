﻿using System.Collections.Generic;
using MoviesAPI.Models;

namespace MoviesAPI.Services
{
    public interface IMoviesService
    {
        Movie AddMovie(Movie movie);
        Movie GetMovie(int id);
        IEnumerable<Movie> SearchMovies(string query);
        bool UpdateMovie(Movie movie);
        bool DeleteMovie(int id);
    }
}
