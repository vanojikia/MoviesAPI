﻿using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using MoviesAPI.Data;
using MoviesAPI.Models;

namespace MoviesAPI.Services
{
    public class MoviesService : IMoviesService
    {
        private readonly MoviesDbContext _context;

        public MoviesService(MoviesDbContext context)
        {
            _context = context;
        }

        public Movie AddMovie(Movie movie)
        {
            if (string.IsNullOrEmpty(movie.Name) ||
                string.IsNullOrEmpty(movie.ShortDescription) ||
                movie.ReleaseYear < 1895 ||
                string.IsNullOrEmpty(movie.Director))
            {
                throw new ArgumentException("Invalid movie details");
            }

            movie.Status = "Active";
            movie.CreationDate = DateTime.Now;
            _context.Movies.Add(movie);
            _context.SaveChanges();

            return movie;
        }

        public Movie GetMovie(int id)
        {
            return _context.Movies.Include(m => m.MovieGenres).ThenInclude(mg => mg.Genre).FirstOrDefault(m => m.Id == id);
        }

        public IEnumerable<Movie> SearchMovies(string query)
        {
            return _context.Movies.Where(m => m.Name.Contains(query) ||
                                              m.ShortDescription.Contains(query) ||
                                              m.Director.Contains(query) ||
                                              m.ReleaseYear.ToString() == query)
                                  .Include(m => m.MovieGenres)
                                  .ThenInclude(mg => mg.Genre);
        }

        public bool UpdateMovie(Movie movie)
        {
            var existingMovie = _context.Movies.Find(movie.Id);
            if (existingMovie == null)
            {
                return false;
            }

            existingMovie.Name = movie.Name;
            existingMovie.ShortDescription = movie.ShortDescription;
            existingMovie.ReleaseYear = movie.ReleaseYear;
            existingMovie.Director = movie.Director;

            _context.SaveChanges();

            return true;
        }

        public bool DeleteMovie(int id)
        {
            var movie = _context.Movies.Find(id);
            if (movie == null)
            {
                return false;
            }

            movie.Status = "Deleted";
            _context.SaveChanges();

            return true;
        }
    }
}
