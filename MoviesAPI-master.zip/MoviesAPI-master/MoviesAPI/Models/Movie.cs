﻿namespace MoviesAPI.Models
{
    public class Movie
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ShortDescription { get; set; }
        public int ReleaseYear { get; set; }
        public string Director { get; set; }
        public string Status { get; set; } // Could be an Enum with "Active" or "Deleted"
        public DateTime CreationDate { get; set; }
        public ICollection<MovieGenre> MovieGenres { get; set; }
    }

}
